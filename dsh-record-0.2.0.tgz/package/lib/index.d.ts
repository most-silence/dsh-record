import z from "@deepseek-ai/schemastery";
import { Context } from "@deepseek-ai/cordis";
import WebServer from "@deepseek-ai/dsh-host-webserver";

//#region src/index.d.ts

type Context$1 = Context & {
  webServer: WebServer;
};
declare const name = "dsh-record";
declare const inject: string[];
interface Config extends Record<string, unknown> {
  format: 'mp3' | 'wav' | 'webm';
  saveMode: 'workspace' | 'custom' | 'off';
  saveDir: string;
}
declare const Config: z<Config>;
declare function apply(ctx: Context$1, config: Config): void;
//#endregion
export { Config, apply, inject, name };